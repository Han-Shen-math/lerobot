"""Audit saved experiment evidence without training or changing experiment inputs."""
import csv
import hashlib
import importlib.metadata
import json
import math
import statistics
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUNDLE = Path(r"E:\CodexTests\lerobot-rope-4835-bundle")
OLD = Path(r"E:\CodexTests\lerobot-pr4902-95e6e92\repo")
FULL = ROOT / "results" / "full"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


pre = read(ROOT / "pre-run-inputs.json")
post = {
    "bundle_hashes": {p.name: sha(p) for p in BUNDLE.iterdir() if p.is_file()},
    "old_repo_commit": git(OLD, "rev-parse", "HEAD"),
    "old_repo_status": subprocess.check_output(["git", "-C", str(OLD), "status", "--porcelain=v1"], text=True),
    "old_repo_file_hashes": {name: sha(OLD / name) for name in ("uv.lock", "pyproject.toml")},
    "installed_packages": [list(item) for item in sorted((d.metadata["Name"], d.version) for d in importlib.metadata.distributions())],
}
save(ROOT / "post-run-inputs.json", post)
assert post == pre, "Bundle or previously verified environment/workspace changed"
assert git(ROOT / "source-repo", "status", "--porcelain=v1") == "", "Pinned checkout is not clean"
source_manifest = read(BUNDLE / "source-manifest.json")
manifest = read(FULL / "manifest.json")
identity = manifest["identity"]
config = identity["config"]
assert git(ROOT / "source-repo", "rev-parse", "HEAD") == source_manifest["pinned_commit"]
assert identity["source"]["source_sha256_raw"] == source_manifest["source_sha256"]
assert identity["source"]["corrected_source_sha256"] == source_manifest["fixed_source_sha256"]
assert config["script_sha256"] == sha(BUNDLE / "experiment.py")
assert config["mode"] == "full" and config["device"] == "cuda"
assert config["steps"] == 1000 and config["folds"] == 3 and config["seeds"] == [11, 22, 33]
math_checks = read(FULL / "math_checks.json")
assert all(item["passed"] for item in math_checks["new"].values())

splits = read(FULL / "splits.json")
test_union = set()
for split in splits:
    train, validation, test = (set(split[key]) for key in ("train", "validation", "test"))
    assert (len(train), len(validation), len(test)) == (64, 16, 40)
    assert not (train & validation or train & test or validation & test)
    assert train | validation | test == set(range(120))
    assert not test_union & test
    test_union |= test
assert test_union == set(range(120))

expected = {(fold, seed, variant) for fold in range(3) for seed in (11, 22, 33) for variant in ("old", "new")}
results = {}
index = []
for path in sorted(FULL.glob("fold_*_seed_*/result.json")):
    result = read(path)
    key = (result["fold"], result["seed"], result["variant"])
    assert key in expected and key not in results
    assert result["complete"] and result["steps"] == 1000
    assert result["all_training_losses_and_gradient_norms_finite"]
    assert result["split"] == splits[result["fold"]]
    assert result["test_episode_ids"] == result["split"]["test"]
    assert result["checkpoint_selection"] == "minimum validation MSE; test never used for selection"
    checkpoint = path.parent / "best.pt"
    assert checkpoint.is_file() and sha(checkpoint) == result["checkpoint_sha256"]
    with (path.parent / "curve.csv").open(newline="", encoding="utf-8") as handle:
        curve = list(csv.DictReader(handle))
    assert len(curve) == 1000
    validation_values = []
    for step, row in enumerate(curve, 1):
        assert int(row["step"]) == step
        assert math.isfinite(float(row["train_mse"])) and math.isfinite(float(row["gradient_norm"]))
        if row["validation_mse"]:
            value = float(row["validation_mse"])
            assert math.isfinite(value)
            validation_values.append((value, step))
    assert [step for _, step in validation_values] == [1, *range(100, 1001, 100)]
    best_val, best_step = min(validation_values)
    assert result["best_step"] == best_step
    assert abs(result["best_validation_mse"] - best_val) <= 1e-12
    scalar_metrics = ("one_step_mse", "long_context_one_step_mse", "persistence_mse", "temporally_mismatched_actions_mse", "autoregressive_same_length_mean_mse", "autoregressive_mean_mse")
    assert all(math.isfinite(result[key]) for key in scalar_metrics)
    assert len(result["autoregressive_mse_by_horizon"]) == 15
    assert all(math.isfinite(x) for x in result["autoregressive_mse_by_horizon"])
    results[key] = result
    index.append({
        "fold": key[0], "seed": key[1], "variant": key[2], "steps": 1000,
        "result": str(path), "curve": str(path.parent / "curve.csv"), "checkpoint": str(checkpoint),
        "result_sha256": sha(path), "curve_sha256": sha(path.parent / "curve.csv"), "checkpoint_sha256": sha(checkpoint),
    })
assert set(results) == expected, f"Incomplete formal run set: {len(results)}/18"
for fold in range(3):
    for seed in (11, 22, 33):
        old, new = (results[fold, seed, variant] for variant in ("old", "new"))
        assert old["initial_state_sha256"] == new["initial_state_sha256"]
        assert old["batch_order_sha256"] == new["batch_order_sha256"]
        assert old["split"] == new["split"] and old["test_episode_ids"] == new["test_episode_ids"]
        assert old["parameter_count"] == new["parameter_count"] == 153808
        assert old["persistence_mse"] == new["persistence_mse"]

per_seed = []
for seed in (11, 22, 33):
    entry = {"seed": seed, "held_out_trajectories": 120}
    for metric in scalar_metrics:
        old_value, new_value = (
            sum(results[fold, seed, variant][metric] * len(splits[fold]["test"]) for fold in range(3)) / 120
            for variant in ("old", "new")
        )
        entry[metric] = {"old": old_value, "new": new_value, "new_minus_old": new_value - old_value,
                         "relative_change_percent": 100 * (new_value - old_value) / old_value}
    entry["action_mismatch_mse_increase"] = {
        variant: sum(results[fold, seed, variant]["action_mismatch_mse_increase"] * len(splits[fold]["test"]) for fold in range(3)) / 120
        for variant in ("old", "new")
    }
    per_seed.append(entry)

timing = read(ROOT / "full-timing.json")
assert timing["Success"] and timing["Steps"] == 1000
gpu_rows = list(csv.DictReader((ROOT / "full-gpu-monitor.csv").open(newline="", encoding="utf-8")))
gpu_samples = [float(row["memory_used_mib"]) for row in gpu_rows if row["memory_used_mib"]]
summary = read(FULL / "summary.json")
assert summary["complete"] and summary["completed_runs"] == 18 and len(summary["pairs"]) == 9
for seed_metrics, original in zip(per_seed, summary["per_seed_trajectory_weighted_fold_aggregation"], strict=True):
    assert seed_metrics["seed"] == original["seed"]
    assert abs(seed_metrics["one_step_mse"]["new_minus_old"] - original["one_step_delta"]) < 1e-12
    assert abs(seed_metrics["autoregressive_mean_mse"]["new_minus_old"] - original["autoregressive_delta"]) < 1e-12

overall = {}
for metric in scalar_metrics:
    old_mean = statistics.mean(item[metric]["old"] for item in per_seed)
    new_mean = statistics.mean(item[metric]["new"] for item in per_seed)
    overall[metric] = {
        "old_seed_mean": old_mean, "new_seed_mean": new_mean, "new_minus_old": new_mean - old_mean,
        "relative_change_percent": 100 * (new_mean - old_mean) / old_mean,
        "initialization_seeds_with_lower_new_error": sum(item[metric]["new_minus_old"] < 0 for item in per_seed),
    }

audit = {
    "complete": True, "completed_formal_runs": 18, "paired_comparisons": 9,
    "full_wall_seconds": timing["WallSeconds"], "full_started": timing["Started"], "full_finished": timing["Finished"],
    "summed_training_seconds": sum(r["training_seconds"] for r in results.values()),
    "summed_total_run_seconds": sum(r["total_run_seconds"] for r in results.values()),
    "peak_pytorch_allocated_bytes": max(r["peak_cuda_memory_allocated_bytes"] for r in results.values()),
    "peak_pytorch_reserved_bytes": max(r["peak_cuda_memory_reserved_bytes"] for r in results.values()),
    "observed_device_wide_memory_peak_mib": max(gpu_samples) if gpu_samples else None,
    "device_wide_monitor_sample_count": len(gpu_samples),
    "device_wide_monitor_error_count": sum(bool(row["error"]) for row in gpu_rows),
    "memory_scope_note": "PyTorch allocator peaks are per-run exact allocator counters. nvidia-smi is sampled every approximately 1 second and includes desktop/other applications; its observed maximum is not an exact experiment-only VRAM peak.",
    "curve_rows_per_run": 1000, "all_saved_training_losses_and_gradients_finite": True,
    "validation_checkpoint_selection_verified": True, "trajectory_splits_disjoint_within_each_fold": True,
    "pair_initialization_and_batch_hashes_match": True, "bundle_unchanged": True,
    "previous_python_dependencies_and_PR_workspace_unchanged": True, "pinned_source_checkout_clean": True,
    "new_math_checks_passed": sum(x["passed"] for x in math_checks["new"].values()),
    "old_math_checks_passed": sum(x["passed"] for x in math_checks["old"].values()),
    "old_math_failures": {k: v for k, v in math_checks["old"].items() if not v["passed"]},
    "gradient_check_scope": "Input gradients compared with independent closed-form reference; not a finite-difference gradcheck or a position-gradient check.",
    "action_control_scope": "Temporal cyclic shift by 3 frames, not a random shuffle.",
    "metric_scope": "MSE over the 4x16 fixed position-derived feature tokens; not physical position MSE or real-video encoder output.",
    "per_seed_paired_metrics": per_seed, "overall_seed_mean_metrics": overall, "formal_runs": index,
}
save(FULL / "audit.json", audit)
save(FULL / "runs-index.json", index)
if not (FULL / "runner-summary.json").exists():
    save(FULL / "runner-summary.json", summary)
summary["independent_execution_audit"] = audit
save(FULL / "summary.json", summary)
runner_report = FULL / "runner-report.txt"
if not runner_report.exists():
    runner_report.write_bytes((FULL / "report.txt").read_bytes())
lines = [runner_report.read_text(encoding="utf-8").rstrip(), "", "INDEPENDENT EXECUTION AUDIT", "Formal runs verified: 18/18; 9 pairs; each 1000 steps, CUDA.",
         f"Full command wall time: {timing['WallSeconds']:.6f} seconds; {timing['Started']} to {timing['Finished']}.",
         f"Sum of recorded optimization time: {audit['summed_training_seconds']:.6f} seconds.",
         f"PyTorch allocated peak: {audit['peak_pytorch_allocated_bytes']} bytes ({audit['peak_pytorch_allocated_bytes']/2**20:.3f} MiB).",
         f"PyTorch reserved peak: {audit['peak_pytorch_reserved_bytes']} bytes ({audit['peak_pytorch_reserved_bytes']/2**20:.3f} MiB).",
         f"Observed device-wide memory peak: {audit['observed_device_wide_memory_peak_mib']} MiB; sampled device-wide, includes desktop.",
         f"Source commit: {source_manifest['pinned_commit']}", f"Original source SHA256: {source_manifest['source_sha256']}",
         f"Corrected runtime source SHA256: {source_manifest['fixed_source_sha256']}", f"Experiment SHA256: {sha(BUNDLE/'experiment.py')}",
         f"Runner SHA256: {sha(BUNDLE/'run-windows.ps1')}",
         "Environment: " + json.dumps(manifest["environment"], ensure_ascii=False),
         "No input, dependency, source checkout, or existing PR workspace change detected.",
         "All 18 CSV curves contain steps 1..1000, finite loss/gradient values, and validation-only checkpoint minima.",
         "Every pair has identical initialization and batch-order hashes and identical held-out trajectory IDs.",
         "Trajectory split: 64 train / 16 validation / 40 test per fold; 3 disjoint test folds cover all 120 trajectories.",
         "Optimization: AdamW lr=0.0003, weight_decay=0.0001, batch_size=16; deterministic FP32/math SDPA; 8 training context frames.",
         "Smoke and pilot each contain 2 short runs and are excluded from the formal 18-run count.", "", "CUDA MATHEMATICS"]
for variant in ("old", "new"):
    for name, outcome in math_checks[variant].items():
        lines.append(f"{variant} {name}: {json.dumps(outcome)}")
lines.extend(["", "Mathematical reference: adjacent pair j rotates by p*10000^(-2*j/D). Corrected pair matrices satisfy R^T R=I and R(p)^T R(q)=R(q-p). Old block repetition uses unequal angles within pairs and is generally non-orthogonal.",
              audit["gradient_check_scope"], audit["action_control_scope"], audit["metric_scope"],
              "Numerical checks cover selected positions/shapes, dim=8 and dim=2, and input gradients; they are not exhaustive backend/mixed-precision/full-PR tests.",
              "", "PER-SEED OLD/NEW METRICS (trajectory-weighted across 3 folds)"])
for entry in per_seed:
    lines.append(f"seed={entry['seed']}")
    for metric in scalar_metrics:
        values = entry[metric]
        lines.append(f"  {metric}: old={values['old']:.10g}; new={values['new']:.10g}; delta={values['new_minus_old']:.10g}; relative_change={values['relative_change_percent']:.6g}%")
    increases = entry["action_mismatch_mse_increase"]
    lines.append(f"  action temporal-mismatch MSE minus correct-action MSE: old={increases['old']:.10g}; new={increases['new']:.10g}. Positive values are observed action sensitivity, not a causal real-world performance claim.")
lines.extend(["", "Each seed summary is descriptive. Three initialization seeds are not three independent datasets. No significance claim.",
              "AR same-length uses 7 predictions from a 2-frame true prefix; AR mean uses 15 predictions, including context-length extrapolation beyond the 8 training frames.",
              "The corrected rotation passes the selected mathematical checks and both versions complete CUDA training. Learning metrics must be interpreted as this synthetic tiny predictor only; no full VLA, pretrained-weight, or robot-performance improvement is established.",
              "Artifacts: runs-index.json enumerates all 18 result/curve/checkpoint paths and hashes. Checkpoints will be archived separately from results.zip."])
lines.extend(["", "OBSERVED SYNTHETIC-TASK CONCLUSION (three-seed descriptive means)"])
for metric, value in overall.items():
    lines.append(f"{metric}: old seed mean={value['old_seed_mean']:.10g}; new seed mean={value['new_seed_mean']:.10g}; change={value['relative_change_percent']:.6g}%; lower new error in {value['initialization_seeds_with_lower_new_error']}/3 seeds.")
primary = overall["one_step_mse"]["new_minus_old"]
recursive = overall["autoregressive_mean_mse"]["new_minus_old"]
if primary < 0 and recursive < 0:
    lines.append("Corrected RoPE has lower observed seed-mean one-step and 15-prediction recursive feature MSE on this fixed synthetic experiment. This is descriptive evidence, not statistical significance or a general performance guarantee.")
elif primary > 0 and recursive > 0:
    lines.append("Corrected RoPE has higher observed seed-mean one-step and recursive feature MSE here despite passing the mathematical rotation checks. The experiment does not show learning improvement on this task.")
elif primary < 0 and recursive > 0:
    lines.append("Corrected RoPE lowers the observed 8-frame one-step feature MSE, but raises the 15-prediction recursive feature MSE. This is a mixed learning result and does not establish general predictor-quality improvement. The longer rollout includes context-length extrapolation.")
else:
    lines.append("Learning results are mixed or unchanged across the primary one-step and recursive metrics. Mathematical correction does not establish consistent learning improvement on this task.")
(FULL / "report.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
print(json.dumps({k: audit[k] for k in ("completed_formal_runs", "full_wall_seconds", "peak_pytorch_allocated_bytes", "peak_pytorch_reserved_bytes", "observed_device_wide_memory_peak_mib", "per_seed_paired_metrics")}, indent=2))
