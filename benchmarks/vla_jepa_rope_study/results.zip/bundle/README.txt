LeRobot VLA-JEPA RoPE paired experiment bundle

1. Copy this bundle to Windows and extract it to:
   E:\CodexTests\lerobot-rope-4835-bundle
2. Give windows-prompt.txt to the Codex chat running on that Windows host.
3. run-windows.ps1 creates its own pinned source checkout and result folders.
   It reuses the previously verified CUDA Python executable without installing
   packages into or modifying the existing PR #4902 checkout.
4. Run smoke, then pilot, then full. See windows-prompt.txt for commands.

Model: actual ActionConditionedVideoPredictor, 153,808 parameters, two layers,
96 hidden dimensions, four heads, 2x2 spatial tokens. No Qwen/V-JEPA weights.
Data: controlled synthetic position/action features, hidden velocity.
Full protocol: three trajectory folds, seeds 11/22/33, old/new, 1,000 steps
per run, batch size 16, eighteen completed runs. Validation selects checkpoints.
FP32 deterministic operations and math SDPA are used for both variants.

The source commit and SHA256 hashes are in source-manifest.json. Both variants
execute separate namespaces; only the two RoPE frequency expansion lines differ.
rope-only.patch shows the difference. world_model_original.py preserves the
pinned upstream source for inspection; execution uses the verified Git checkout.
The upstream source is licensed under Apache-2.0; see LEROBOT-LICENSE.

Primary one-step metric uses eight context frames, as in training. Sixteen-frame
evaluation is separately labelled context-length extrapolation. Recursive rollout
uses two true prefix frames, then predicted features. The initial hidden velocity
creates irreducible uncertainty in the very first one-step prediction. These
fixed features are not a video encoder or a real robot environment.

The CPU validation included in local-validation.json is only a dispatch/logic
check: eighteen runs with ONE optimization step each, mathematical tests, and
resume guards. It is not a model-quality result, a full-budget training run,
Windows execution, or CUDA evidence. Windows GPU training remains pending.

Formal output: results\full\report.txt, summary.json, math_checks.json,
manifest.json, splits.json, per-run curve.csv, result.json and best.pt.
Keep all positive, negative and neutral results. No pretrained-model or robot
performance improvement can be inferred from this synthetic experiment alone.

Only publish results after reviewing the complete evidence. This bundle does
not push code or send GitHub messages.
