"""Sample device-wide GPU memory; PyTorch per-run allocator peaks remain authoritative."""
import argparse
import csv
import datetime
import subprocess
import time
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--out", type=Path, required=True)
parser.add_argument("--stop", type=Path, required=True)
args = parser.parse_args()
with args.out.open("w", newline="", encoding="utf-8") as handle:
    writer = csv.writer(handle)
    writer.writerow(["timestamp_utc", "gpu_index", "memory_used_mib", "gpu_utilization_percent", "temperature_c", "power_w", "error"])
    while not args.stop.exists():
        timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
        try:
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=index,memory.used,utilization.gpu,temperature.gpu,power.draw", "--format=csv,noheader,nounits"],
                capture_output=True, text=True, check=True, timeout=10,
            )
            for row in csv.reader(result.stdout.splitlines(), skipinitialspace=True):
                writer.writerow([timestamp, *row, ""])
        except Exception as error:
            writer.writerow([timestamp, "", "", "", "", "", f"{type(error).__name__}: {error}"])
        handle.flush()
        time.sleep(1)
