"""Package completed, audited RoPE evidence without changing experimental inputs.

Uses only the Python standard library. Run only after training and monitoring
have finished and audit_results.py has succeeded. All writes stay beside this
script. Existing output archives/manifests are never overwritten or removed.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BUNDLE = Path(r"E:\CodexTests\lerobot-rope-4835-bundle")
FULL = ROOT / "results" / "full"
SOURCE = ROOT / "source-repo"
OUTPUT_NAMES = {"results.zip", "checkpoints.zip", "checksums.json", "archive-manifest.json"}
CHUNK_SIZE = 1024 * 1024


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(CHUNK_SIZE), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_stream(handle) -> str:
    digest = hashlib.sha256()
    for chunk in iter(lambda: handle.read(CHUNK_SIZE), b""):
        digest.update(chunk)
    return digest.hexdigest()


def encoded_json(value) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def write_exclusive(path: Path, data: bytes) -> None:
    require(path.parent.resolve() == ROOT, f"Output escaped work root: {path}")
    with path.open("xb") as handle:
        handle.write(data)


def add_payload(payload: dict[str, Path], member: str, path: Path) -> None:
    require(path.is_file() and not path.is_symlink(), f"Missing file or symlink refused: {path}")
    require(not Path(member).is_absolute() and ".." not in Path(member).parts, f"Unsafe archive member: {member}")
    require(member not in payload and member != "checksums.json", f"Duplicate archive member: {member}")
    payload[member] = path


def verify_completion() -> dict[str, int]:
    required_files = [
        FULL / "audit.json", FULL / "runs-index.json", FULL / "report.txt",
        FULL / "summary.json", FULL / "manifest.json", FULL / "math_checks.json",
        FULL / "splits.json", ROOT / "full-timing.json", ROOT / "pre-run-inputs.json",
        ROOT / "post-run-inputs.json", ROOT / "full-gpu-monitor.csv",
    ]
    required_files.extend(ROOT / f"{phase}-console.log" for phase in ("smoke", "pilot", "full"))
    for path in required_files:
        require(path.is_file(), f"Completion evidence missing: {path}")
    audit = read_json(FULL / "audit.json")
    summary = read_json(FULL / "summary.json")
    require(audit.get("complete") is True and audit.get("completed_formal_runs") == 18,
            "Formal execution audit must confirm 18 completed runs.")
    require(summary.get("complete") is True and summary.get("completed_runs") == 18,
            "Formal summary does not confirm 18 completed runs.")
    require(len(read_json(FULL / "runs-index.json")) == 18, "Formal runs-index must contain 18 runs.")
    require(read_json(ROOT / "full-timing.json").get("Success") is True,
            "Formal command was not marked successful.")
    require(read_json(ROOT / "pre-run-inputs.json") == read_json(ROOT / "post-run-inputs.json"),
            "Before/after input and environment snapshots differ.")
    for flag in (
        "all_saved_training_losses_and_gradients_finite", "validation_checkpoint_selection_verified",
        "trajectory_splits_disjoint_within_each_fold", "pair_initialization_and_batch_hashes_match",
        "bundle_unchanged", "previous_python_dependencies_and_PR_workspace_unchanged",
        "pinned_source_checkout_clean",
    ):
        require(audit.get(flag) is True, f"Execution audit did not pass: {flag}")

    counts = {}
    for phase, folds, seeds, steps in (
        ("full", range(3), (11, 22, 33), 1000),
        ("smoke", range(1), (11,), 2),
        ("pilot", range(1), (11,), 200),
    ):
        phase_dir = ROOT / "results" / phase
        expected = {f"fold_{fold}_seed_{seed}_{variant}" for fold in folds for seed in seeds
                    for variant in ("old", "new")}
        actual = {path.parent.name for path in phase_dir.glob("fold_*_seed_*/result.json")}
        require(actual == expected, f"Unexpected or incomplete {phase} run set: {actual}")
        for run_name in sorted(expected):
            result = read_json(phase_dir / run_name / "result.json")
            require(result.get("complete") is True and result.get("steps") == steps,
                    f"Incomplete or unexpected budget: {phase}/{run_name}")
            checkpoint = phase_dir / run_name / "best.pt"
            require(checkpoint.is_file(), f"Checkpoint missing: {checkpoint}")
            require(sha256_file(checkpoint) == result.get("checkpoint_sha256"),
                    f"Checkpoint hash differs from result metadata: {checkpoint}")
        counts[phase] = len(expected)

    source_manifest = read_json(BUNDLE / "source-manifest.json")
    identity = read_json(FULL / "manifest.json")["identity"]
    source_path = SOURCE / source_manifest["source_path"]
    require(identity["source"]["git_commit"] == source_manifest["pinned_commit"], "Source commit mismatch.")
    require(sha256_file(source_path) == source_manifest["source_sha256"], "Source SHA256 mismatch.")
    for name, expected_hash in read_json(BUNDLE / "bundle-sha256.json").items():
        require(sha256_file(BUNDLE / name) == expected_hash, f"Bundle hash mismatch: {name}")
    return counts


def collect_payloads() -> tuple[dict[str, Path], dict[str, Path]]:
    results_payload: dict[str, Path] = {}
    checkpoint_payload: dict[str, Path] = {}
    # This root is the isolated experiment directory. Preserve all its evidence
    # and operation scripts; omit only generated packaging outputs and checkout.
    for current, directories, filenames in os.walk(ROOT, followlinks=False):
        current_path = Path(current)
        if current_path == ROOT:
            directories[:] = [name for name in directories if name != "source-repo"]
        for name in directories:
            require(not (current_path / name).is_symlink(), f"Symlink directory refused: {current_path / name}")
        for filename in sorted(filenames):
            path = current_path / filename
            if current_path == ROOT and filename in OUTPUT_NAMES:
                continue
            if "__pycache__" in path.relative_to(ROOT).parts or path.suffix == ".pyc":
                continue
            member = path.relative_to(ROOT).as_posix()
            if path.suffix.lower() in {".pt", ".pth", ".ckpt"}:
                require(path.parent.parent in {ROOT / "results" / phase for phase in ("smoke", "pilot", "full")}
                        and path.name == "best.pt", f"Unexpected checkpoint location: {path}")
                add_payload(checkpoint_payload, member, path)
            else:
                add_payload(results_payload, member, path)
    for path in sorted(BUNDLE.rglob("*")):
        require(not path.is_symlink(), f"Bundle symlink refused: {path}")
        if path.is_file():
            add_payload(results_payload, "bundle/" + path.relative_to(BUNDLE).as_posix(), path)
    source_manifest = read_json(BUNDLE / "source-manifest.json")
    for relative in (source_manifest["source_path"], "LICENSE"):
        add_payload(results_payload, "source-repo/" + relative, SOURCE / relative)
    return results_payload, checkpoint_payload


def payload_records(payload: dict[str, Path]) -> dict[str, dict]:
    return {member: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
            for member, path in sorted(payload.items())}


def create_and_verify_archive(path: Path, payload: dict[str, Path], records: dict, checksums: bytes) -> dict:
    require(path.parent.resolve() == ROOT, f"Archive escaped work root: {path}")
    with zipfile.ZipFile(path, mode="x", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
        for member, source in sorted(payload.items()):
            archive.write(source, arcname=member)
        archive.writestr("checksums.json", checksums)
    with zipfile.ZipFile(path, "r") as archive:
        require(archive.testzip() is None, f"Archive CRC failure: {path}")
        names = archive.namelist()
        require(len(names) == len(set(names)), f"Archive contains duplicate members: {path}")
        require(set(names) == set(records) | {"checksums.json"}, f"Archive member set mismatch: {path}")
        require(archive.read("checksums.json") == checksums, f"Embedded checksums differ: {path}")
        for member, record in records.items():
            require(archive.getinfo(member).file_size == record["size_bytes"], f"Archive member size mismatch: {member}")
            with archive.open(member, "r") as handle:
                actual_hash = sha256_stream(handle)
            require(actual_hash == record["sha256"], f"Archive member SHA256 mismatch: {member}")
    return {
        "path": str(path), "sha256": sha256_file(path), "size_bytes": path.stat().st_size,
        "member_count": len(records) + 1, "payload_member_count": len(records),
        "uncompressed_payload_bytes": sum(item["size_bytes"] for item in records.values()),
        "crc_verified": True, "member_sha256_verified": True,
    }


def main() -> None:
    for filename in sorted(OUTPUT_NAMES):
        require(not (ROOT / filename).exists(), f"Refusing to overwrite existing packaging output: {ROOT / filename}")
    checkpoint_counts = verify_completion()
    results_payload, checkpoint_payload = collect_payloads()
    require(len(checkpoint_payload) == sum(checkpoint_counts.values()) == 22,
            "Expected 22 checkpoints: 18 full, 2 smoke, 2 pilot.")
    records = {
        "results.zip": payload_records(results_payload),
        "checkpoints.zip": payload_records(checkpoint_payload),
    }
    checksum_document = {
        "format_version": 1, "algorithm": "SHA256", "created_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Every payload member in both archives. Each archive embeds this same checksums.json.",
        "self_hash_note": "checksums.json does not hash itself. Its bytes are verified against the external copy, and archive-manifest.json records the external copy SHA256.",
        "archive_manifest_note": "archive-manifest.json is external to both archives to avoid circular archive hashes.",
        "checkpoint_counts": checkpoint_counts,
        "checkpoint_layout": "results/{full,smoke,pilot}/fold_<fold>_seed_<seed>_<variant>/best.pt",
        "archives": records,
    }
    checksums = encoded_json(checksum_document)
    write_exclusive(ROOT / "checksums.json", checksums)
    archive_records = {}
    for filename, payload in (("results.zip", results_payload), ("checkpoints.zip", checkpoint_payload)):
        archive_records[filename] = create_and_verify_archive(ROOT / filename, payload, records[filename], checksums)
    archive_manifest = {
        "format_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
        "work_root": str(ROOT), "formal_completed_runs": 18,
        "checkpoint_counts": checkpoint_counts, "checkpoint_total": sum(checkpoint_counts.values()),
        "checkpoint_layout": checksum_document["checkpoint_layout"],
        "checksums_path": str(ROOT / "checksums.json"),
        "checksums_sha256": hashlib.sha256(checksums).hexdigest(),
        "archives": archive_records,
        "verification": "Both ZIP CRC checks and every payload SHA256/size matched checksums.json. The embedded checksum file bytes matched the external file.",
        "self_hash_note": "The external archive-manifest.json does not hash itself.",
        "failure_policy": "No existing file is overwritten. If packaging fails, any newly created partial output is retained for inspection; nothing is deleted or moved.",
    }
    write_exclusive(ROOT / "archive-manifest.json", encoded_json(archive_manifest))
    print(json.dumps({
        "verified": True, "formal_runs": 18, "checkpoints": checkpoint_counts,
        "results_zip": str(ROOT / "results.zip"), "checkpoints_zip": str(ROOT / "checkpoints.zip"),
        "checksums": str(ROOT / "checksums.json"), "archive_manifest": str(ROOT / "archive-manifest.json"),
        "archive_payload_members": {name: info["payload_member_count"] for name, info in archive_records.items()},
    }, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"Packaging failed; outputs retained: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
